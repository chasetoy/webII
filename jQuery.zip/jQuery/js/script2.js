$(function() {
   $('.fancybox').fancybox();
   $( '.tooltip' ).tooltip();
   $('#datepicker').datepicker();
});
